package com.karle.redis.dao;

public interface JedisDao {

	public double zincrby(String key, double score, String member);

}
