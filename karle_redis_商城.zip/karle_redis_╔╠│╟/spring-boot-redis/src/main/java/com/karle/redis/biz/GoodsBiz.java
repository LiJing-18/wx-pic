package com.karle.redis.biz;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.karle.redis.constant.RCRedisKey;
import com.karle.redis.vo.CategoryVO;
import com.karle.redis.vo.GoodsListVO;
import com.karle.redis.vo.GoodsVO;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

@Service
public class GoodsBiz {

	@Autowired
	private JedisPool jedisPool;

	// 获取分类列表
	public List<CategoryVO> category() {
		Jedis jedis = jedisPool.getResource();
		try {
			Set<String> cacheCategory = jedis.sunion(RCRedisKey.GOODS_CATEGORY);
			if (cacheCategory.isEmpty())
				return null;
			List<CategoryVO> result = new ArrayList<CategoryVO>(cacheCategory.size());
			for (String item : cacheCategory)
				result.add(JSONObject.parseObject(item, CategoryVO.class));
			return result;
		} finally {
			jedis.close();
		}
	}

	// 获取商品列表
	public List<GoodsListVO> goodsList(int categoryId) {
		Jedis jedis = jedisPool.getResource();
		try {
			Set<String> categoryGoods = jedis.zrevrange(String.format(RCRedisKey.GOODS_LIST, categoryId), 0, -1);
			if (categoryGoods.isEmpty())
				return null;
			List<GoodsListVO> result = new ArrayList<GoodsListVO>(categoryGoods.size());
			for (String item : categoryGoods) {
				GoodsListVO pCache = JSONObject.parseObject(item, GoodsListVO.class);
				pCache.setScore(jedis.zscore(String.format(RCRedisKey.GOODS_LIST, categoryId), item).intValue());
				result.add(pCache);
			}
			return result;
		} finally {
			jedis.close();
		}
	}

	// 获取商品详情
	public GoodsVO goodsDetail(Integer gid) {
		Jedis jedis = jedisPool.getResource();
		try {
			String cacheGoods = jedis.hget(RCRedisKey.GOODS_INFO, gid + "");
			if (cacheGoods == null)
				return null;
			GoodsVO result = JSONObject.parseObject(cacheGoods, GoodsVO.class);
			jedis.zincrby(String.format(RCRedisKey.GOODS_LIST, result.getCategoryId()), 1, cacheGoods);
			return result;
		} finally {
			jedis.close();
		}
	}

}
