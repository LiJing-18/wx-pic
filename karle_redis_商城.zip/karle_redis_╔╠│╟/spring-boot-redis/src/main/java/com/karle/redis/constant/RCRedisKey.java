package com.karle.redis.constant;

/**
 * Redis Keys
 * 
 * @author Karle
 *
 * @2017年10月11日
 *
 */
public class RCRedisKey {

	/** 初始化商品信息 **/
	public static final String INIT_GOODS_INFO = "init_goods_info";

	/** 商品列表 ,p1-分类id **/
	public static final String GOODS_LIST = "googds_list_%s";

	/** 商品信息 **/
	public static final String GOODS_INFO = "googds_info";

	/** 商品分类 **/
	public static final String GOODS_CATEGORY = "googds_category";

}
