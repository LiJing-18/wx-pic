package com.karle.redis.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.karle.redis.biz.GoodsBiz;

/**
 * 商城控制器 <br>
 * 博客：http://csdn.karle.vip/
 * 
 * @author Karle
 * 
 */
@Controller
@RequestMapping("goods")
public class GoodsController {

	@Autowired
	private GoodsBiz goodsBiz;

	@Autowired
	private HttpServletRequest request;

	// 获取分类列表
	@RequestMapping(value = "category")
	public String category() {
		request.setAttribute("pageData", goodsBiz.category());
		return "goods/category";
	}

	// 获取商品列表
	@RequestMapping(value = "goods_list")
	public String goodsList(@RequestParam Integer cid) {
		request.setAttribute("pageData", goodsBiz.goodsList(cid));
		return "goods/goods_list";
	}

	// 获取商品详情
	@RequestMapping(value = "goods_detail")
	public String goodsDetail(@RequestParam Integer gid) {
		request.setAttribute("info", goodsBiz.goodsDetail(gid));
		return "goods/goods_detail";
	}

}
