package com.karle.redis.controller;

import java.util.List;

import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.karle.redis.vo.Result;

/**
 * 全局异常处理
 * 
 * @author Karle
 *
 */
@ResponseBody
@ControllerAdvice
public class GlobalExceptionHandler {

	// 请求参数缺失
	@ExceptionHandler(BindException.class)
	public Result<String> BindExceptionException(BindException e) {
		List<ObjectError> errors = e.getBindingResult().getAllErrors();
		return new Result<String>(false, errors.isEmpty() ? "参数校验失败" : errors.get(0).getDefaultMessage(), null);
	}

	// 默认处理
	@ExceptionHandler(Exception.class)
	public Result<String> Exception(Exception e) {
		return new Result<String>(false, "系统异常", null);
	}
}
