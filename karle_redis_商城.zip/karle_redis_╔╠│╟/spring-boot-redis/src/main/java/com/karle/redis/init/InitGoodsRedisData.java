package com.karle.redis.init;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.karle.redis.constant.RCRedisKey;
import com.karle.redis.vo.CategoryVO;
import com.karle.redis.vo.GoodsVO;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.Transaction;

/**
 * 初始化商品缓存信息<br>
 * 博客：http://csdn.karle.vip/
 * 
 * @author Karle
 * @2017年10月11日
 */
@Component
public class InitGoodsRedisData implements ApplicationListener<ContextRefreshedEvent> {

	@Autowired
	private JedisPool jedisPool;

	@Override
	public void onApplicationEvent(ContextRefreshedEvent c) {
		Jedis jedis = jedisPool.getResource();
		if (jedis.scard(RCRedisKey.GOODS_CATEGORY) > 0) {
			System.out.println("已经缓存商品初始化数据***************");
			return;
		}
		Transaction transaction = jedis.multi();
		initCategoryData(transaction);
		initGoodsData(transaction);
		transaction.exec();
		jedis.close();
		System.out.println("写入商品初始化数据***************OK");
	}

	// 初始化商品分类
	private void initCategoryData(Transaction transaction) {
		transaction.sadd(RCRedisKey.GOODS_CATEGORY, JSONObject.toJSONString(new CategoryVO(1, "手机")),
				JSONObject.toJSONString(new CategoryVO(2, "平板")));
	}

	// 初始化商品信息
	private void initGoodsData(Transaction transaction) {

		// 手机
		Map<String, Double> phoneScoreMembers = new HashMap<String, Double>(5);

		String goods11 = JSONObject.toJSONString(new GoodsVO(11, 1, "Iphone X", 8388.00,
				"https://img11.360buyimg.com/n5/s75x75_jfs/t9907/361/46671134/65420/7d66b903/59c47a15N36a2fc0d.jpg"));
		phoneScoreMembers.put(goods11, 0d);
		transaction.hset(RCRedisKey.GOODS_INFO, 11 + "", goods11);

		String goods12 = JSONObject.toJSONString(new GoodsVO(12, 1, "Iphone8 P", 6688.00,
				"https://img10.360buyimg.com/n5/s54x54_jfs/t7339/80/2994230157/58546/a4b72d95/59b85837N990db7d3.jpg"));
		phoneScoreMembers.put(goods12, 0d);
		transaction.hset(RCRedisKey.GOODS_INFO, 12 + "", goods12);

		String goods13 = JSONObject.toJSONString(new GoodsVO(13, 1, "三星S8", 5688.00,
				"https://img14.360buyimg.com/n5/s54x54_jfs/t5095/313/1561100036/253747/b2dfce2f/59119ddcNc7305e8b.jpg"));
		phoneScoreMembers.put(goods13, 0d);
		transaction.hset(RCRedisKey.GOODS_INFO, 13 + "", goods13);

		String goods14 = JSONObject.toJSONString(new GoodsVO(14, 1, "小米MIX2", 3599.00,
				"https://img13.360buyimg.com/n5/s54x54_jfs/t9214/51/1590664916/300151/a59b7cd3/59bb8691Naca717e9.jpg"));
		phoneScoreMembers.put(goods14, 0d);
		transaction.hset(RCRedisKey.GOODS_INFO, 14 + "", goods14);

		String goods15 = JSONObject.toJSONString(new GoodsVO(15, 1, "华为P10", 3488.00,
				"https://img14.360buyimg.com/n5/s54x54_jfs/t4333/208/365266204/337840/e9e7bd9a/58b3f51aN10566aa1.jpg"));
		phoneScoreMembers.put(goods15, 0d);
		transaction.hset(RCRedisKey.GOODS_INFO, 15 + "", goods15);

		transaction.zadd(String.format(RCRedisKey.GOODS_LIST, 1), phoneScoreMembers);

		// 电脑
		Map<String, Double> computerScoreMembers = new HashMap<String, Double>(5);
		String goods21 = JSONObject.toJSONString(new GoodsVO(21, 2, "Apple iPad", 3258.00,
				"https://img12.360buyimg.com/n5/s54x54_jfs/t3214/177/9256496777/621169/2a1735b5/58d16208N55e7302b.jpg"));
		computerScoreMembers.put(goods21, 0d);
		transaction.hset(RCRedisKey.GOODS_INFO, 21 + "", goods21);

		String goods22 = JSONObject.toJSONString(new GoodsVO(22, 2, "华为M3", 2258.00,
				"https://img10.360buyimg.com/n5/s54x54_jfs/t3235/143/2924985643/316383/370982db/57e8d527Ncb5ce343.jpg"));
		computerScoreMembers.put(goods22, 0d);
		transaction.hset(RCRedisKey.GOODS_INFO, 22 + "", goods22);

		String goods23 = JSONObject.toJSONString(new GoodsVO(23, 2, "Apple iPad mini 4", 3098.00,
				"https://img14.360buyimg.com/n5/s54x54_jfs/t9751/18/332152129/67998/3cef982f/59cc62ccN582dbd8a.jpg"));
		computerScoreMembers.put(goods23, 0d);
		transaction.hset(RCRedisKey.GOODS_INFO, 23 + "", goods23);

		String goods24 = JSONObject.toJSONString(new GoodsVO(24, 2, "Apple iPad Pro", 5888.00,
				"https://img10.360buyimg.com/n5/s54x54_jfs/t6679/178/76604977/301064/4e10cb22/5938ffa2Nb4d435f2.jpg"));
		computerScoreMembers.put(goods24, 0d);
		transaction.hset(RCRedisKey.GOODS_INFO, 24 + "", goods24);

		String goods25 = JSONObject.toJSONString(new GoodsVO(25, 2, "Surface Pro", 9888.00,
				"https://img10.360buyimg.com/n5/s54x54_jfs/t5617/321/1137763311/121847/b9326254/5923eb44Ndae8df59.jpg"));
		computerScoreMembers.put(goods25, 0d);
		transaction.hset(RCRedisKey.GOODS_INFO, 25 + "", goods25);

		transaction.zadd(String.format(RCRedisKey.GOODS_LIST, 2), computerScoreMembers);

	}

}
