package com.karle.redis.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

@Repository
public class JedisDaoImpl implements JedisDao {

	@Autowired
	private JedisPool jedisPool;

	@Override
	public double zincrby(String key, double score, String member) {
		Jedis jedis = jedisPool.getResource();
		Double zincrby = jedis.zincrby(key, score, member);
		jedis.close();
		return zincrby;
	}
	
	

}
