package com.karle.redis.conf;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import redis.clients.jedis.JedisPool;

@Configuration
@EnableCaching
public class ConfJedisPool {

	@Value("${spring.redis.host}")
	private String host;

	@Value("${spring.redis.port}")
	private Integer port;

	@Bean
	public JedisPool redisPoolFactory() {
		JedisPool jedisPool = new JedisPool(host, port);
		return jedisPool;
	}

}
